# milestone3 > 2022-11-20 8:35pm
https://universe.roboflow.com/dataminingmilestone3/milestone3-ta1bc

Provided by a Roboflow user
License: CC BY 4.0

